import { enterHost } from "@/lib/hosts/context";
import { pageHostId } from "@/lib/hosts/request";
import { isLocalHost } from "@/lib/hosts/store";
import { requirePermission } from "@/lib/auth/guard";
import { hasPermission } from "@/lib/auth/session";
import { failedLogins } from "@/lib/security/fail2ban";
import { storedForwards } from "@/lib/security/upnp";
import { latestScans } from "@/lib/security/vuln";
import { SecurityScreen } from "./SecurityScreen";

export const dynamic = "force-dynamic";

/**
 * Güvenlik ekranı (M3.7 + M3.8).
 *
 * Sayfa açılışında YALNIZCA veritabanından okunanlar geliyor. CVE taraması,
 * SSH denetimi ve UPnP sorgusu container açıyor ya da ağa çıkıyor — hepsi
 * kendi düğmesiyle, kullanıcı isteyince çalışıyor. Aksi halde ekran her
 * açılışta dakikalarca yüklenirdi.
 */
export default async function SecurityPage() {
  const session = await requirePermission("security.view");
  const hostId = await pageHostId({ agent: true });
  enterHost(hostId);
  // Uzak sunucuda yalnızca SSH denetimi var; diğer izleyiciler yerel.
  const local = isLocalHost(hostId);

  return (
    <SecurityScreen
      initialScans={local ? latestScans() : []}
      initialForwards={local ? storedForwards() : []}
      initialFailedLogins={local ? failedLogins() : []}
      canManage={hasPermission(session.user, "security.manage")}
      remote={!local}
    />
  );
}
